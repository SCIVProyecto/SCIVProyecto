<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="stylesheet" href="css/Dashboard.css">
    <link rel="icon" type="image/ico" href="images/icon_page.png" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Quicksand:600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <title>Panel Principal</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
    <link rel="stylesheet" href="CSS/Dashboard.css">
  </head>
  
  <body>
    <div class="container-fluid">
      <div class="row justify-content-center align-content-center">
        <div class="col-8 barra">
          <a href="index.html">
          <h4 class="text-light">Naila's Beauty</h4>
          </a>
        </div>
      <div class="col-4 text-right barra">
        <ul class="navbar-nav mr-auto">
          <li>
            <a href="index.html" class="px-3 text-light perfil dropdown-toggle" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-user-circle user"></i></a>
            <div class="dropdown-menu" aria-labelledby="navbar-dropdown">
            <a class="dropdown-item menuperfil cerrar" href="login.php"><i class="fas fa-sign-out-alt m-1"></i>Salir</a>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>   
  </header>

  <div class="container-fluid">
    <div class="row">
      <div class="barra-lateral col-12 col-sm-auto">
        <nav class="menu d-flex d-sm-block justify-content-center flex-wrap">
            <a href="Dashboard.php"><i class="fas fa-cogs logo-settings"></i><span>Panel Principal</span></a>
            <a href="productos.php"><i class="fas fa-cogs logo-settings"></i><span>Productos</span></a>
            <a href="categorias.php"><i class="fas fa-cogs logo-settings"></i><span>Categorias</span></a>
            <a href="sub_categoria.php"><i class="fas fa-cogs logo-settings"></i><span>Sub Categoria</span></a>
            <a href="usuarios.php"><i class="fas fa-cogs logo-settings"></i><span>Usuarios</span></a>
        </nav>
      </div>


      </body>
</html>