<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Recuperar Contraseña</title>
    <link href="recuperar.css" rel="stylesheet">
  </head>
  <body>

    <div class="form">
        <img src="img/Logo_SCIV.jpg" class="php" alt="php image">
        <h1>Recuperar contraseña</h1><p>
        <form>
            <div class="inputBox">
                <label for="Correo">Correo Electronico</label><p>
                    <input name="correo "type="text" placeholder="Ingresar Correo electronico" autocomplete />
                <input type="submit" value="Enviar" />
            </div>
            <a href="Login.php">Volver a Login</a>
            </p>
        </form>
    </div>