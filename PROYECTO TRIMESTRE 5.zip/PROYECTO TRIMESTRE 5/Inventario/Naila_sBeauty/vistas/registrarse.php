<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Registrarse</title>
    <link href="registrarse.css" rel="stylesheet">
  </head>
<body>

    <div class="form">
        <img src="img/Logo_SCIV.jpg" class="php" alt="php image">
        <h1>Crear nueva cuenta</h1>
    <form >
        <label for="Username">Nombre y apellido</label>
        <input type="text" placeholder="Registrar Nombre y Apellido"/>
        <label for="Correo">Correo electronico</label>
        <input name="correo "type="text" placeholder="Ingresar Correo electronico" autocomplete />
        <label for="direccion">Dirección</label>
        <input type="text" placeholder="Ingresar Dirección"/>
        <label for="Numero">Numero de contacto</label>
        <input type="text" placeholder="Ingresar Numero de contacto"/>
        <label for="password">Contraseña</label> 
        <input type="password" placeholder="Contraseña"/>
        <input type="submit" value="Crear Cuenta" />
        <a href="Login.php">Volver a Login</a><p>
        </p>
    </form>
</div>

  <body>