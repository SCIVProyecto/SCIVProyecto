<div class="carrito" id="carrito">
        <div class="header-carrito">
            <h2>Tu Carrito</h2>
        </div>
        <div class="carrito-items">
           
            <div class="carrito-item">
                <img src="img/SkinCare_Producto5.jpg" width="80px" alt="">
                <div class="carrito-item-detalles">
                    <span class="carrito-item-titulo">Nombre</span>
                    <div class="selector-cantidad">
                        <i class="fa-solid fa-minus restar-cantidad"></i>
                        <input type="text" value="1" class="carrito-item-cantidad" disabled>
                        <i class="fa-solid fa-plus sumar-cantidad"></i>
                    </div>
                    <span class="carrito-item-precio">$87.000</span>
                </div>
                <span class="btn-eliminar">
                    <i class="fa-solid fa-trash"></i>
                </span>
            </div>
                       
            <div class="carrito-item">
                <img src="img/Maquillaje_Producto7.jpg" width="80px" alt="">
                <div class="carrito-item-detalles">
                    <span class="carrito-item-titulo"></span>
                    <div class="selector-cantidad">
                        <i class="fa-solid fa-minus restar-cantidad"></i>
                        <input type="text" value="3" class="carrito-item-cantidad" disabled>
                        <i class="fa-solid fa-plus sumar-cantidad"></i>
                    </div>
                    <span class="carrito-item-precio">$99.000</span>
                </div>
                <span class="btn-eliminar">
                    <i class="fa-solid fa-trash"></i>
                </span>
            </div>
            <div class="carrito-total">
                <div class="fila">
                    <strong>Tu Total</strong>
                    <span class="carrito-precio-total">
                     $120.000,00
                    </span>
                </div>
                <a href="checkout.php"><button class="btn-pagar"> Pagar <i class="fa-solid fa-bag-shopping"></i></button></a>
            </div>              


        </div>
    </div> 
        
            
           