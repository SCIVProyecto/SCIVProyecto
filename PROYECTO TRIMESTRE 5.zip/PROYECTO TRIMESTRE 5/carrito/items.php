<div class="contenedor-items">
        <div class="item">
                    <span class="titulo-item">Nombre</span>
                    <img src="img/SkinCare_Producto5.jpg" alt="" class="img-item">
                    <span class="precio-item">$87.000</span>
                    <button class="boton-item"><i class="fa fa-shopping-cart"></i> Agregar al Carrito</button>
                </div>
    
                <div class="item">
                    <span class="titulo-item">Nombre</span>
                    <img src="img/Maquillaje_Producto7.jpg" alt="" class="img-item">
                    <span class="precio-item">$99.000</span>
                    <button class="boton-item"><i class="fa fa-shopping-cart"></i> Agregar al Carrito</button>
                </div>
    
                <div class="item">
                    <span class="titulo-item">Knock Nap</span>
                    <img src="img/Maquillaje_Producto3.jpg" alt="" class="img-item">
                    <span class="precio-item">$56.000</span>
                    <button class="boton-item"><i class="fa fa-shopping-cart"></i> Agregar al Carrito</button>
                </div>
    
                <div class="item">
                    <span class="titulo-item">La Night</span>
                    <img src="img/Maquillaje_Producto4.jpg" alt="" class="img-item">
                    <span class="precio-item">$58.000</span>
                    <button class="boton-item"><i class="fa fa-shopping-cart"></i> Agregar al Carrito</button>
                    
                </div>
    
                <div class="item">
                    <span class="titulo-item">Silver All</span>
                    <img src="img/SkinCare_Producto3.jpg" alt="" class="img-item">
                    <span class="precio-item">$112.000</span>
                    <button class="boton-item"><i class="fa fa-shopping-cart"></i> Agregar al Carrito</button>
                </div>
    </div>