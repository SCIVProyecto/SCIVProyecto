<h2>Direccion de facturacion</h2>
    <div class="row">
        <div class="col-md-6">
            <label>Primer Nombre</label>
            <input class="form-control" type="text" placeholder="Primer Nombre">
        </div>
        <div class="col-md-6">
            <label>Apellido"</label>
            <input class="form-control" type="text" placeholder="Segundo Nombre">
        </div>
        <div class="col-md-6">
            <label>Correo</label>
            <input class="form-control" type="text" placeholder="E-mail">
        </div>
        <div class="col-md-6">
            <label>Celular</label>
            <input class="form-control" type="text" placeholder="Celular">
        </div>
        <div class="col-md-12">
            <label>Direccion</label>
            <input class="form-control" type="text" placeholder="Direccion">
        </div>
        <div class="col-md-6">
            <label>Departamento</label>
                <select class="custom-select">
                    <option selected>Cundimarca</option>
                    <option>Cundimarca</option>
                    <option>Boyaca</option>
                    <option>Antioquia</option>
                </select>
        </div>
        <div class="col-md-6">
            <label>Ciudad</label>
            <input class="form-control" type="text" placeholder="Ciudad">
        </div>
        <div class="col-md-6">
        <label>Localidad</label>
            <input class="form-control" type="text" placeholder="Localidad">
        </div>
    </div>
    </div>
</div>
</div>
<div class="col-lg-4">
    <div class="checkout-inner">
        <div class="checkout-summary">
            <h1>Total del carro</h1>
            <p>Product Name<span>$99</span></p>
            <p class="sub-total">Sub Total<span>$99</span></p>
            <p class="ship-cost">Costo de Envio<span>$1</span></p>
            <h2>Total<span>$100</span></h2>
        </div>
<div class="checkout-payment">
    <div class="payment-methods">
        <h1>Metodos de Pago</h1>
        <div class="payment-method">
            <div class="custom-control custom-radio">
                <input type="radio" class="custom-control-input" id="payment-1" name="payment">
                <label class="custom-control-label" for="payment-1">PSE</label>
            </div>
        </div>
        <div class="payment-method">
        <div class="custom-control custom-radio">
            <input type="radio" class="custom-control-input" id="payment-2" name="payment">
            <label class="custom-control-label" for="payment-2">Tarjeta de Credito</label>
        </div>
    </div>
    <div class="checkout-btn">
        <a href="index.html"><button class="btn-pagar"> Pagar <i class="fa-solid fa-bag-shopping"></i></button></a>
    </div>
</div>
                   