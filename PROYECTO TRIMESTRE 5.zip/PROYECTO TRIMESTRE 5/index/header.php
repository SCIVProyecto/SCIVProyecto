<div class="top-bar">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <i class="fa fa-envelope"></i>
                    soporte@nailasbeauty.com
            </div>
            <div class="col-sm-6">
                <i class="fa fa-phone-alt"></i>
                    3245678906
            </div>
        </div>
    </div>
</div>

<div class="nav">
    <div class="container-fluid">
        <nav class="navbar navbar-expand-md bg-dark navbar-dark">
            <a href="#" class="navbar-brand">MENU</a>
                <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>

        <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
            <div class="navbar-nav mr-auto">
                <a href="lista_productos.php" class="nav-item nav-link active">Productos</a>
                <a href="contactame.php" class="nav-item nav-link active">Contactenos</a>
            </div>
        <div class="navbar-nav ml-auto">
            <div class="nav-item dropdown">
                <a href="cuenta.php" class="nav-link dropdown-toggle" data-toggle="dropdown">Mi cuenta</a>
                    <div class="dropdown-menu">
                        <a href="cuenta.php" class="dropdown-item">Mi cuenta</a>
                        <a href="login/index.php" class="dropdown-item">Ingresar</a>
                        <a href="login/registro.php" class="dropdown-item">Registrarse</a>
                        <a href="login/view/user/index.php" class="dropdown-item">Salir</a>
        </a>
                    </div>
            </div>
        </div>
        </div>
        </nav>
    </div>
</div>

<div class="bottom-bar">
    <div class="container-fluid">
        <div class="row align-items-center">
                    <div class="col-md-3">
                        <div class="logo">
                            <a href="index.php">
                                <img src="img/logo.png" alt="Logo">
                            </a>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="search">
                            <input type="text" placeholder="Buscar">
                            <button><i class="fa fa-search"></i></button>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="user">
                            <a href="favoritos.php" class="btn wishlist">
                                <i class="fa fa-heart"></i>
                                <span>(0)</span>
                            </a>
                            <a href="carrito.php" class="btn cart">
                                <i class="fa fa-shopping-cart"></i>
                                <span>(0)</span>
                            </a>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>