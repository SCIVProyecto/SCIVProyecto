<div class="call-to-action">
    <div class="container-fluid">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h1>Llamanos</h1>
            </div>
        <div class="col-md-6">
            <a href="tel:0123456789">3245678906</a>
        </div>
        </div>
    </div>
</div>