<div class="newsletter">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <h1>Suscribete</h1>
            </div>
            <div class="col-md-6">
                <div class="form">
                    <input type="email" value="Escribe tu correo aqui">
                        <button>Enviar</button>
                </div>
            </div>
        </div>
    </div>
</div>