<div class="header">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-3">
                    <nav class="navbar bg-light">
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link" href="lista_productos.php"><i class="fas fa-heart"></i>Mas vendidos</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="lista_productos.php"><i class="fas fa-box"></i>Nuevos</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="lista_productos.php"><i class="fas fa-theater-masks"></i>SkinCare</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="lista_productos.php"><i class="fa fa-shopping-bag"></i>Maquillaje</a>
                            </li>
                    </nav>
                </div>
                <div class="col-md-6">
                    <div class="header-slider normal-slider">
                        <div class="header-slider-item">
                            <img src="img/SkinCare_Producto1.jpg" alt="Slider Image" />
                            <div class="header-slider-caption">
                                <p>SkinCare</p>
                                <a class="btn" href="lista_productos.php"><i class="fa fa-shopping-cart"></i>Compra ahora</a>
                            </div>
                        </div>
                        <div class="header-slider-item">
                            <img src="img/Maquillaje_Producto1.jpg" alt="Slider Image" />
                            <div class="header-slider-caption">
                                <p>Maquillaje</p>
                                <a class="btn" href="lista_productos.php"><i class="fa fa-shopping-cart"></i>Compra Ahora</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-md-3">
                    <div class="header-img">
                        <div class="img-item">
                            <img src="img/SkinCare_Producto2.jpg" />
                            <a class="img-text" href="">
                                <p>Cremas</p>
                            </a>
                        </div>
                        <div class="img-item">
                            <img src="img/Maquillaje_Producto2.jpg" />
                            <a class="img-text" href="">
                                <p>Paleta de Colores</p>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
         </div>
    </div>


