<?php

namespace App\Config;

class UrlBase {
    const urlBase = 'https://inventario-naila.test/api';
}