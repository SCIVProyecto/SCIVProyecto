<?php

namespace App\Controllers;

use App\Config\ResponseHttp;
use App\Config\Security;
use App\Models\ProductModel;
use Rakit\Validation\Validator;

class ProductController extends BaseController
{

    /**************************Listado**************************/
    final public function getAll(string $endPoint)
    {
        if ($this->getMethod() == 'get' && $endPoint == $this->getRoute()) {
            Security::validateTokenJwt(Security::secretKey());
            echo json_encode(ProductModel::getAll());
            exit;
        }
    }

    /************************** Nuevo **************************/
    final public function postSave(string $endPoint)
    {
        if ($this->getMethod() == 'post' && $endPoint == $this->getRoute()) {
            Security::validateTokenJwt(Security::secretKey());
            $validator = new Validator;
            $validator->setMessage('required', ":attribute es requerido.");
            $validator->setMessage('integer', ":attribute debe ser número entero.");
            $validator->setMessage('min', ":attribute , debe ser mínimo :min caracteres.");
            $validator->setMessage('max', ":attribute , debe ser máximo :max caracteres.");
            $validator->setMessage('uploaded_file', ":attribute , El archivo es demasiado grande, el tamaño máximo es 2M.");

            $validation = $validator->validate($_POST + $_FILES, [
                'codigo'        => 'required|min:3|max:40',
                'nombre'        => 'required|min:3|max:40',
                'precio'        => 'required|numeric',
                'stock'        => 'required|numeric',
                'foto'        => 'required|uploaded_file:0,2M,png,jpeg',
                'categoria_id'        => 'required|integer',
                'subcategoria_id'        => 'required|integer',
                'usuario_id'        => 'required|integer',
            ]);

            if ($validation->fails()) {
                $errors = $validation->errors();
                echo json_encode(ResponseHttp::status400($errors->all()[0]));
            } else {
                
                ProductModel::setCodigo($this->getParam()['codigo']);
                ProductModel::setNombre($this->getParam()['nombre']);
                ProductModel::setPrecio($this->getParam()['precio']);
                ProductModel::setStock($this->getParam()['stock']);
                ProductModel::setCategoriaId($this->getParam()['categoria_id']);
                ProductModel::setSubcategoriaId($this->getParam()['subcategoria_id']);
                ProductModel::setUsuarioId($this->getParam()['usuario_id']);
                ProductModel::setFile($_FILES);
                //new ProductModel($this->getParam(), $_FILES);
                echo json_encode(ProductModel::postSave());
            }

            exit;
        }
    }

    /************************** Actualizar **************************/
    final public function patchUpdate(string $endPoint)
    {
        if ($this->getMethod() == 'post' && $endPoint == $this->getRoute()) {
            Security::validateTokenJwt(Security::secretKey());
            $validator = new Validator;
            $validator->setMessage('required', ":attribute es requerido.");
            $validator->setMessage('integer', ":attribute debe ser número entero.");
            $validator->setMessage('min', ":attribute , debe ser mínimo :min caracteres.");
            $validator->setMessage('max', ":attribute , debe ser máximo :max caracteres.");
            $validator->setMessage('uploaded_file', ":attribute , El archivo es demasiado grande, el tamaño máximo es 2M.");

            $validation = $validator->validate($_POST + $_FILES, [
                'id'        => 'required|integer',
                'codigo'        => 'required|min:3|max:40',
                'nombre'        => 'required|min:3|max:40',
                'precio'        => 'required|numeric',
                'stock'        => 'required|numeric',
                'foto'        => 'uploaded_file:0,2M,png,jpeg',
                'categoria_id'        => 'required|integer',
                'subcategoria_id'        => 'required|integer',
                'usuario_id'        => 'required|integer',
            ]);

            if ($validation->fails()) {
                $errors = $validation->errors();
                echo json_encode(ResponseHttp::status400($errors->all()[0]));
            } else {

                ProductModel::setId($this->getParam()['id']);
                ProductModel::setCodigo($this->getParam()['codigo']);
                ProductModel::setNombre($this->getParam()['nombre']);
                ProductModel::setPrecio($this->getParam()['precio']);
                ProductModel::setStock($this->getParam()['stock']);
                ProductModel::setCategoriaId($this->getParam()['categoria_id']);
                ProductModel::setSubcategoriaId($this->getParam()['subcategoria_id']);
                ProductModel::setUsuarioId($this->getParam()['usuario_id']);
                ProductModel::setFile($_FILES);
                //new ProductModel($this->getParam(), $_FILES);
                echo json_encode(ProductModel::patchUpdate());
            }

            exit;
        }
    }

    /**************************producto por ID**************************/
    final public function getProduct(string $endPoint)
    {
        if ($this->getMethod() == 'get' && $endPoint == $this->getRoute()) {

            //Security::validateTokenJwt(Security::secretKey());
            $id = $this->getAttribute()[1];
            if (!isset($id)) {
                echo json_encode(ResponseHttp::status400('El id es requerido'));
            } else if (!preg_match(self::$validate_number, $id)) {
                echo json_encode(ResponseHttp::status400('El id solo admite números'));
            } else {
                ProductModel::setId($id);
                echo json_encode(ProductModel::getProduct());
                exit;
            }
            exit;
        }
    }
    /**************************Producto por Texto**************************/
    final public function getProductSearch(string $endPoint)
    {
        $texto = $_GET['query'] ?? '';
        if ($this->getMethod() == 'get' && $endPoint == $this->getRoute()) {
            //Security::validateTokenJwt(Security::secretKey());
            if (!isset($texto) || empty($texto)) {
                echo json_encode(ResponseHttp::status400('query es requerido'));
            } else {
                ProductModel::setQueryValue($_GET['query']);
                echo json_encode(ProductModel::getProductSearch());
                exit;
            }
            exit;
        }
    }



    /************************** Eliminar **************************/
    final public function deleteProduct(string $endPoint)
    {
        if ($this->getMethod() == 'delete' && $this->getRoute() == $endPoint) {
            Security::validateTokenJwt(Security::secretKey());

            if (empty($this->getParam()['product_id'])) {
                echo json_encode(ResponseHttp::status400('product_id es requerido'));
            } else {
                ProductModel::setId($this->getParam()['product_id']);
                echo json_encode(ProductModel::deleteProduct());
            }
            exit;
        }
    }

    public static function slugify($text, string $divider = '-')
    {
        // replace non letter or digits by divider
        $text = preg_replace('~[^\pL\d]+~u', $divider, $text);

        // transliterate
        $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);

        // remove unwanted characters
        $text = preg_replace('~[^-\w]+~', '', $text);

        // trim
        $text = trim($text, $divider);

        // remove duplicate divider
        $text = preg_replace('~-+~', $divider, $text);

        // lowercase
        $text = strtolower($text);

        if (empty($text)) {
            return 'n-a';
        }

        return $text;
    }
}
