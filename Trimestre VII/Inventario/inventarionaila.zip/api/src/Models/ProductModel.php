<?php

namespace App\Models;

use App\Config\ResponseHttp;
use App\Config\Security;
use App\DB\ConnectionDB;
use Dotenv\Dotenv;
use App\DB\Sql;

class ProductModel extends ConnectionDB
{

    //Propiedades de la base de datos
    private static int $id;
    private static $codigo;
    private static string $nombre;
    private static float $precio;
    private static int $stock;
    private static string $foto;
    private static int $categoria_id;
    private static $file;
    private static int $subcategoria_id;
    private static int $usuario_id;
    private static string $queryValue;
    private static string $url;


    public function __construct(array $data, $file)
    {

        self::$id      = $data['id'];
        self::$codigo      = $data['codigo'];
        self::$nombre   = $data['nombre'];
        self::$precio   = $data['precio'];
        self::$stock   = $data['stock'];
        self::$foto   = $data['foto'];
        self::$categoria_id   = $data['categoria_id'];
        self::$subcategoria_id   = $data['subcategoria_id'];
        self::$usuario_id   = $data['usuario_id'];
        self::$queryValue = $data['queryValue'];
        self::$file = $file;
    }

    /**************************Metodos Getter**************************/
    final public static function getId()
    {
        return self::$id;
    }
    final public static function getCodigo()
    {
        return self::$codigo;
    }
    final public static function getFile()
    {
        return self::$file;
    }
    final public static function getUrl()
    {
        return self::$url;
    }

    final public static function getNombre()
    {
        return self::$nombre;
    }
    final public static function getPrecio()
    {
        return self::$precio;
    }
    final public static function getStock()
    {
        return self::$stock;
    }
    final public static function getFoto()
    {
        return self::$foto;
    }
    final public static function getCategoriaId()
    {
        return self::$categoria_id;
    }
    final public static function getSubcategoriaId()
    {
        return self::$subcategoria_id;
    }
    final public static function getUsuarioId()
    {
        return self::$usuario_id;
    }

    final public static function getQueryValue()
    {
        return self::$queryValue;
    }



    /**************************Metodos Setter**************************/

    final public static function setId(string $id)
    {
        self::$id = $id;
    }
    final public static function setFile($file)
    {
        self::$file = $file;
    }
    final public static function setUrl(string $url)
    {
        self::$url = $url;
    }
    final public static function setCodigo(string $codigo)
    {
        self::$codigo = $codigo;
    }
    final public static function setNombre(string $nombre)
    {
        self::$nombre = $nombre;
    }
    final public static function setPrecio(string $precio)
    {
        self::$precio = $precio;
    }
    final public static function setStock(string $stock)
    {
        self::$stock = $stock;
    }
    final public static function setFoto(string $foto)
    {
        self::$foto = $foto;
    }
    final public static function setCategoriaId(string $categoria_id)
    {
        self::$categoria_id = $categoria_id;
    }
    final public static function setSubcategoriaId(string $subcategoria_id)
    {
        self::$subcategoria_id = $subcategoria_id;
    }
    final public static function setUsuarioId(string $usuario_id)
    {
        self::$usuario_id = $usuario_id;
    }

    final public static function setQueryValue(string $queryValue)
    {
        self::$queryValue = $queryValue;
    }


    /************************** Listado **************************/
    final public static function getAll()
    {
        try {
            $con = self::getConnection();
            $query = $con->prepare("SELECT pr.*,subcat.sub_categoria_id,subcat.sub_categoria_nombre,
            cat.categoria_id,cat.categoria_nombre,us.usuario_id,us.usuario_nombre
             FROM producto AS pr
            JOIN  sub_categoria AS subcat ON pr.subcategoria_id=subcat.sub_categoria_id
            JOIN categoria AS cat ON pr.categoria_id=cat.categoria_id 
            JOIN usuario AS us ON pr.usuario_id=us.usuario_id
            ORDER BY producto_nombre ASC");
            $query->execute();

            $dat = $query->fetchAll(\PDO::FETCH_ASSOC);
            $data = [];
            foreach ($dat as $res) {

                array_push($data, [
                    'id'  => $res['producto_id'],
                    'codigo'  => $res['producto_codigo'],
                    'nombre'  => $res['producto_nombre'],
                    'precio'  => number_format($res['producto_precio'], 2),
                    'stock'  => $res['producto_stock'],
                    'foto'  => Security::getUrlBase() . "/img/" . $res['producto_foto'],
                    'categoria_id'  => $res['categoria_id'],
                    'categoria_nombre'  => $res['categoria_nombre'],
                    'subcategoria_id'  => $res['sub_categoria_id'],
                    'subcategoria_nombre'  => $res['sub_categoria_nombre'],
                    'usuario_id'  => $res['usuario_id'],
                    'usuario_nombre'  => $res['usuario_nombre'],

                ]);
            }
            return ResponseHttp::status200('completado', $data);
            exit;
        } catch (\PDOException $e) {
            error_log("ProductModel::getAll -> " . $e);
            die(json_encode(ResponseHttp::status500('No se pueden obtener los datos')));
        }
    }



    /**************************Nuevo producto**************************/
    final public static function postSave()
    {
        if (Sql::exists("SELECT producto_nombre FROM producto WHERE producto_nombre = :user", ":user", self::getNombre())) {
            return ResponseHttp::status400('El nombre de Producto existe');
        } else if (Sql::exists("SELECT producto_codigo FROM producto WHERE producto_codigo = :cate", ":cate", self::getCodigo())) {
            return ResponseHttp::status400('El codigo ya existe');
        } else if (!Sql::exists("SELECT categoria_id FROM categoria WHERE categoria_id = :cate", ":cate", self::getCategoriaId())) {
            return ResponseHttp::status400('Categoria no existe');
        } else if (!Sql::exists("SELECT sub_categoria_id FROM sub_categoria WHERE sub_categoria_id = :cate", ":cate", self::getSubcategoriaId())) {
            return ResponseHttp::status400('Subcategoria no existe');
        } else if (!Sql::exists("SELECT usuario_id FROM usuario WHERE usuario_id = :cate", ":cate", self::getUsuarioId())) {
            return ResponseHttp::status400('Usuario no existe');
        } else {

            try {

                $resImg = Security::uploadImage(self::getFile(), 'foto');

                //self::setUrl($resImg['path']);
                self::setFoto($resImg['name']);

                $con = self::getConnection();
                $query1 = "INSERT INTO producto (producto_codigo,producto_nombre,producto_precio,
             producto_stock,producto_foto,categoria_id,usuario_id,subcategoria_id) VALUES";
                $query2 = "(:codigo,:nombre,:precio,:stock,:foto,:categoria_id,:usuario_id,:subcategoria_id)";
                $query = $con->prepare($query1 . $query2);
                $query->execute([
                    ':codigo'     => self::getCodigo(),
                    ':nombre'  => self::getNombre(),
                    ':precio'     => self::getPrecio(),
                    ':stock'  => self::getStock(),
                    ':foto' => self::getFoto(),
                    ':categoria_id' => self::getCategoriaId(),
                    ':usuario_id' => self::getUsuarioId(),
                    ':subcategoria_id' => self::getSubcategoriaId(),

                ]);
                if ($query->rowCount() > 0) {
                    return ResponseHttp::status200('Producto registrado exitosamente');
                } else {
                    return ResponseHttp::status500('No se puede registrar el producto');
                }
            } catch (\PDOException $e) {
                error_log('ProductModel::post -> ' . $e);
                die(json_encode(ResponseHttp::status500()));
            }
        }
    }

    

    /**************************Actualizar producto**************************/
    final public static function patchUpdate()
    {
        try {
            

            if (!Sql::exists("SELECT categoria_id FROM categoria WHERE categoria_id = :cate", ":cate", self::getCategoriaId())) {
                return ResponseHttp::status400('Categoria no existe');
            } else if (!Sql::exists("SELECT sub_categoria_id FROM sub_categoria WHERE sub_categoria_id = :cate", ":cate", self::getSubcategoriaId())) {
                return ResponseHttp::status400('Subcategoria no existe');
            } else if (!Sql::exists("SELECT usuario_id FROM usuario WHERE usuario_id = :cate", ":cate", self::getUsuarioId())) {
                return ResponseHttp::status400('Usuario no existe');
            } else {
            
         
                $con = self::getConnection();
            
                $query1 = $con->prepare("SELECT * FROM producto WHERE producto_id= :id");
                $query1->execute([
                    ':id' => self::getId()
                ]);
                $dat = $query1->fetchAll(\PDO::FETCH_ASSOC);
                $oldFoto = $dat[0]['producto_foto'];
                
            if((self::getFile()['foto']['size'])>0){
                $resImg = Security::uploadImage(self::getFile(), 'foto');
                self::setFoto($resImg['name']);
                unlink($_SERVER['DOCUMENT_ROOT'] . "/img/$oldFoto");
            }else{
                
                self::setFoto($oldFoto);
            }
            
            
            $con1 = self::getConnection();
            $query = $con1->prepare("UPDATE producto SET producto_codigo=:codigo,producto_nombre=:nombre,
            producto_precio=:precio, producto_stock=:stock,producto_foto=:foto,categoria_id=:categoria_id,
            usuario_id=:usuario_id,subcategoria_id=:subcategoria_id WHERE producto_id = :id");
            $query->execute([
                ':id'     => self::getId(),
                ':codigo'     => self::getCodigo(),
                ':nombre'  => self::getNombre(),
                ':precio'     => self::getPrecio(),
                ':stock'  => self::getStock(),
                ':foto' => self::getFoto(),
                ':categoria_id' => self::getCategoriaId(),
                ':usuario_id' => self::getUsuarioId(),
                ':subcategoria_id' => self::getSubcategoriaId(),
                
            ]);
            if ($query->rowCount() > 0) {
                return ResponseHttp::status200('Producto actualizado exitosamente');
            } else {
                return ResponseHttp::status500('No se puede actualizar el producto');
            }
        }    
        } catch (\PDOException $e) {
            error_log('ProductModel::patchUpdate -> ' . $e);
            die(json_encode(ResponseHttp::status500()));
        }
       
    }


    /**************************Producto por ID**************************/
    final public static function getProduct()
    {
        try {
            $con = self::getConnection();
            $query = $con->prepare("SELECT pr.*,subcat.sub_categoria_id,subcat.sub_categoria_nombre,
            cat.categoria_id,cat.categoria_nombre,us.usuario_id,us.usuario_nombre
             FROM producto AS pr
            JOIN  sub_categoria AS subcat ON pr.subcategoria_id=subcat.sub_categoria_id
            JOIN categoria AS cat ON pr.categoria_id=cat.categoria_id 
            JOIN usuario AS us ON pr.usuario_id=us.usuario_id
             WHERE pr.producto_id = :id");
            $query->execute([
                ':id' => self::getId()
            ]);

            if ($query->rowCount() == 0) {
                return ResponseHttp::status400('Producto No encontrado');
            } else {

                $dat = $query->fetchAll(\PDO::FETCH_ASSOC);
                $data = [];
                foreach ($dat as $res) {

                    array_push($data, [
                        'id'  => $res['producto_id'],
                        'codigo'  => $res['producto_codigo'],
                        'nombre'  => $res['producto_nombre'],
                        'precio'  => number_format($res['producto_precio'], 2),
                        'stock'  => $res['producto_stock'],
                        'foto'  => Security::getUrlBase() . "/img/" . $res['producto_foto'],
                        'categoria_id'  => $res['categoria_id'],
                        'categoria_nombre'  => $res['categoria_nombre'],
                        'subcategoria_id'  => $res['sub_categoria_id'],
                        'subcategoria_nombre'  => $res['sub_categoria_nombre'],
                        'usuario_id'  => $res['usuario_id'],
                        'usuario_nombre'  => $res['usuario_nombre'],

                    ]);
                }
                return ResponseHttp::status200('completado', $data);
            }
        } catch (\PDOException $e) {
            error_log("ProductModel::getProduct -> " . $e);
            die(json_encode(ResponseHttp::status500('No se pueden obtener los datos del Producto')));
        }
    }



    /************************** Producto por texto **************************/
    final public static function getProductSearch()
    {
        try {
            $con = self::getConnection();
            $query = $con->prepare("SELECT pr.*,subcat.sub_categoria_id,subcat.sub_categoria_nombre,
            cat.categoria_id,cat.categoria_nombre,us.usuario_id,us.usuario_nombre
             FROM producto AS pr
            JOIN  sub_categoria AS subcat ON pr.subcategoria_id=subcat.sub_categoria_id
            JOIN categoria AS cat ON pr.categoria_id=cat.categoria_id 
            JOIN usuario AS us ON pr.usuario_id=us.usuario_id WHERE 
             pr.producto_nombre LIKE :queryValue
             OR pr.producto_codigo LIKE :queryValue              
             ORDER BY producto_nombre ASC");

            $query->execute([
                ':queryValue' =>  '%' . self::getQueryValue() . '%'
            ]);


            if ($query->rowCount() == 0) {
                return ResponseHttp::status400('Producto No encontrado');
            } else {

                $dat = $query->fetchAll(\PDO::FETCH_ASSOC);
                $data = [];
                foreach ($dat as $res) {

                    array_push($data, [
                        'id'  => $res['producto_id'],
                        'codigo'  => $res['producto_codigo'],
                        'nombre'  => $res['producto_nombre'],
                        'precio'  => number_format($res['producto_precio'], 2),
                        'stock'  => $res['producto_stock'],
                        'foto'  => Security::getUrlBase() . "/img/" . $res['producto_foto'],
                        'categoria_id'  => $res['categoria_id'],
                        'categoria_nombre'  => $res['categoria_nombre'],
                        'subcategoria_id'  => $res['sub_categoria_id'],
                        'subcategoria_nombre'  => $res['sub_categoria_nombre'],
                        'usuario_id'  => $res['usuario_id'],
                        'usuario_nombre'  => $res['usuario_nombre'],
                    ]);
                }
                return ResponseHttp::status200('completado', $data);
            }
        } catch (\PDOException $e) {
            error_log("ProductModel::getProductSearch -> " . $e);
            die(json_encode(ResponseHttp::status500('No se pueden obtener los datos del Producto')));
        }
    }


    /************************** Eliminar**************************/
    final public static function deleteProduct()
    {
        try {
            $con = self::getConnection();
            $query = $con->prepare("SELECT * FROM producto WHERE producto_id = :id");
            $query->execute([
                ':id' => self::getId()
            ]);
            $dat = $query->fetchAll(\PDO::FETCH_ASSOC);
            self::setFoto($dat[0]['producto_foto']);

            $con   = self::getConnection();
            $query2 = $con->prepare("DELETE FROM producto WHERE producto_id = :id");
            $query2->execute([
                ':id' => self::getId()
            ]);


            if ($query2->rowCount() > 0) {
                $name = self::getFoto();
                $imgLocal = unlink($_SERVER['DOCUMENT_ROOT'] . "/img/$name");
                if ($imgLocal) {
                    return ResponseHttp::status200('Producto eliminado exitosamente');
                } else {
                    //return ResponseHttp::status500('No se puede eliminar la imagen local');
                }
            } else {
                return ResponseHttp::status500('No se puede eliminar el producto');
            }
        } catch (\PDOException $e) {
            error_log("ProductModel::deleteProduct -> " . $e);
            die(json_encode(ResponseHttp::status500('No se puede eliminar el Producto')));
        }
    }
}
