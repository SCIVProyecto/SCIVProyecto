<?php

namespace App\Models;

use App\Config\ResponseHttp;
use App\Config\Security;
use App\DB\ConnectionDB;
use App\DB\Sql;

class SubCategoryModel extends ConnectionDB
{

    //Propiedades de la base de datos
    private static string $nombre;
    private static string $ubicacion;
    private static int $id;
    private static int $categoria_id;
    private static string $queryValue;


    public function __construct(array $data)
    {
        self::$nombre   = $data['nombre'];
        self::$ubicacion      = $data['ubicacion'];
        self::$id      = $data['id'];
        self::$categoria_id      = $data['categoria_id'];
        self::$queryValue = $data['queryValue'];
    }

    /**************************Metodos Getter**************************/
    final public static function getNombre()
    {
        return self::$nombre;
    }
    final public static function getId()
    {
        return self::$id;
    }
    final public static function getCategoriaId()
    {
        return self::$categoria_id;
    }
    final public static function getUbicacion()
    {
        return self::$ubicacion;
    }
    final public static function getQueryValue()
    {
        return self::$queryValue;
    }



    /**************************Metodos Setter**************************/
    final public static function setNombre(string $nombre)
    {
        self::$nombre = $nombre;
    }
    final public static function setUbicacion(string $ubicacion)
    {
        self::$ubicacion = $ubicacion;
    }

    final public static function setId(string $id)
    {
        self::$id = $id;
    }
    final public static function setCategoriaId(string $categoria_id)
    {
        self::$categoria_id = $categoria_id;
    }
    final public static function setQueryValue(string $queryValue)
    {
        self::$queryValue = $queryValue;
    }


    /************************** Listado **************************/
    final public static function getAll()
    {
        try {
            $con = self::getConnection();
            $query = $con->prepare("SELECT * FROM sub_categoria ORDER BY sub_categoria_nombre ASC");
            $query->execute();

            $dat = $query->fetchAll(\PDO::FETCH_ASSOC);
            $data = [];
            foreach ($dat as $res) {

                array_push($data, [
                    'id'  => $res['sub_categoria_id'],
                    'nombre'  => $res['sub_categoria_nombre'],
                    'ubicacion'  => $res['sub_categoria_ubicacion'],
                    'categoria_id'  => $res['categoria_id'],

                ]);
            }
            return ResponseHttp::status200('completado', $data);
            exit;
        } catch (\PDOException $e) {
            error_log("SubCategoryModel::getAll -> " . $e);
            die(json_encode(ResponseHttp::status500('No se pueden obtener los datos')));
        }
    }


    /************************** Nuevo **************************/
    final public static function postSave()
    {
        if (Sql::exists("SELECT sub_categoria_nombre FROM sub_categoria WHERE sub_categoria_nombre = :user", ":user", self::getNombre())) {
            return ResponseHttp::status400('El nombre ingresado ya se encuentra registrado, por favor elija otro');
        } else if (!Sql::exists("SELECT categoria_nombre FROM categoria WHERE categoria_id = :id", ":id", self::getCategoriaId())) {
            return ResponseHttp::status400('Categoría no existe');
        } else {

            try {
                $con = self::getConnection();
                $query1 = "INSERT INTO sub_categoria (sub_categoria_nombre,sub_categoria_ubicacion,categoria_id) VALUES";
                $query2 = "(:nombre,:ubicacion,:categoria_id)";
                $query = $con->prepare($query1 . $query2);
                $query->execute([
                    ':nombre'  => self::getNombre(),
                    ':ubicacion'     => self::getUbicacion(),
                    ':categoria_id'     => self::getCategoriaId(),

                ]);
                if ($query->rowCount() > 0) {
                    $lasId = $con->lastInsertId();
                    $query3 = $con->prepare("SELECT * FROM sub_categoria WHERE sub_categoria_id = :id");
                    $query3->execute([
                        ':id' => $lasId
                    ]);
                    $dat = $query3->fetchAll(\PDO::FETCH_ASSOC);
                    $data = [];
                    foreach ($dat as $res) {

                        array_push($data, [
                            'id'  => $res['sub_categoria_id'],
                            'nombre'  => $res['sub_categoria_nombre'],
                            'ubicacion'  => $res['sub_categoria_ubicacion'],
                            'categoria_id'  => $res['categoria_id'],

                        ]);
                    }
                    return ResponseHttp::status200('Subcategoría registrada exitosamente', $data);
                } else {
                    return ResponseHttp::status500('No se puede registrar la Subcategoría');
                }
            } catch (\PDOException $e) {
                error_log('SubCategoryModel::post -> ' . $e);
                die(json_encode(ResponseHttp::status500()));
            }
        }
    }

    /**************************Categoria por ID**************************/
    final public static function getCategory()
    {
        try {
            $con = self::getConnection();
            $query = $con->prepare("SELECT * FROM sub_categoria WHERE sub_categoria_id = :id");
            $query->execute([
                ':id' => self::getId()
            ]);

            if ($query->rowCount() == 0) {
                return ResponseHttp::status400('Subcategoría No encontrada');
            } else {

                $dat = $query->fetchAll(\PDO::FETCH_ASSOC);
                $data = [];
                foreach ($dat as $res) {

                    array_push($data, [
                        'id'  => $res['sub_categoria_id'],
                        'nombre'  => $res['sub_categoria_nombre'],
                        'ubicacion'  => $res['sub_categoria_ubicacion'],
                        'categoria_id'  => $res['categoria_id'],

                    ]);
                }
                return ResponseHttp::status200('completado', $data);
            }
        } catch (\PDOException $e) {
            error_log("SubCategoryModel::getCategory -> " . $e);
            die(json_encode(ResponseHttp::status500('No se pueden obtener los datos de la sub_categoria')));
        }
    }


    /****************************** Actualizar **************************/
    final public static function patchUpdate()
    {
        try {
            $con1 = self::getConnection();
            $query1 = $con1->prepare("SELECT * FROM sub_categoria WHERE sub_categoria_id = :id");
            $query1->execute([
                ':id' => self::getId()
            ]);


            if ($query1->rowCount() == 0) {
                return ResponseHttp::status400('Subcategoría No encontrada');
            } else if (!Sql::exists("SELECT categoria_nombre FROM categoria WHERE categoria_id = :id", ":id", self::getCategoriaId())) {
                return ResponseHttp::status400('Categoría no existe');
            } else {
                $con = self::getConnection();
                $query = $con->prepare("UPDATE sub_categoria SET sub_categoria_nombre=:nombre,
            sub_categoria_ubicacion=:ubicacion, categoria_id=:categoria_id WHERE sub_categoria_id = :id");
                $query->execute([
                    ':id' => self::getId(),
                    ':nombre'  => self::getNombre(),
                    ':ubicacion'     => self::getUbicacion(),
                    ':categoria_id'     => self::getCategoriaId(),
                ]);

                if ($query->rowCount() > 0) {

                    $query3 = $con->prepare("SELECT * FROM sub_categoria WHERE sub_categoria_id = :id");
                    $query3->execute([
                        ':id' => self::getId(),
                    ]);
                    $dat = $query3->fetchAll(\PDO::FETCH_ASSOC);
                    $data = [];
                    foreach ($dat as $res) {

                        array_push($data, [
                            'id'  => $res['sub_categoria_id'],
                            'nombre'  => $res['sub_categoria_nombre'],
                            'ubicacion'  => $res['sub_categoria_ubicacion'],
                            'categoria_id'  => $res['categoria_id'],

                        ]);
                    }
                    return ResponseHttp::status200('Subcategoría actualizada exitosamente', $data);
                } else {
                    return ResponseHttp::status500('No se ha podido actualizar Subcategoría');
                }
            }
        } catch (\PDOException $e) {
            error_log("SubCategoryModel::patchUpdate -> " . $e);
            die(json_encode(ResponseHttp::status500()));
        }
    }

    /************************** sub_categoria por texto **************************/
    final public static function getCategorySearch()
    {
        try {
            $con = self::getConnection();
            $query = $con->prepare("SELECT * FROM sub_categoria WHERE 
             sub_categoria_nombre LIKE :queryValue
             OR sub_categoria_ubicacion LIKE :queryValue              
             ORDER BY sub_categoria_nombre ASC");

            $query->execute([
                ':queryValue' =>  '%' . self::getQueryValue() . '%'
            ]);


            if ($query->rowCount() == 0) {
                return ResponseHttp::status400('Subcategoría No encontrada');
            } else {

                $dat = $query->fetchAll(\PDO::FETCH_ASSOC);
                $data = [];
                foreach ($dat as $res) {

                    array_push($data, [
                        'id'  => $res['sub_categoria_id'],
                        'nombre'  => $res['sub_categoria_nombre'],
                        'ubicacion'  => $res['sub_categoria_ubicacion']
                    ]);
                }
                return ResponseHttp::status200('completado', $data);
            }
        } catch (\PDOException $e) {
            error_log("SubCategoryModel::getCategorySearch -> " . $e);
            die(json_encode(ResponseHttp::status500('No se pueden obtener los datos de la sub_categoria')));
        }
    }

    /************************** Obtener  Productos **************************/
    final public static function getProducts()
    {
        try {
            $con1 = self::getConnection();
            $query1 = $con1->prepare("SELECT * FROM sub_categoria WHERE sub_categoria_id = :id");
            $query1->execute([
                ':id' => self::getId()
            ]);


            if ($query1->rowCount() == 0) {
                return ResponseHttp::status400('Subcategoría No encontrada');
            } else {

                $con = self::getConnection();
                $query = $con->prepare("SELECT pr.*, cat.sub_categoria_id,cat.sub_categoria_nombre,
                us.usuario_id,us.usuario_nombre
                FROM producto AS pr
               JOIN sub_categoria AS cat ON pr.subcategoria_id=cat.sub_categoria_id
               JOIN usuario AS us ON pr.usuario_id=us.usuario_id
                WHERE pr.subcategoria_id = :id ORDER BY producto_nombre ASC");
                
                $query->execute([
                    ':id' => self::getId()
                ]);


                if ($query->rowCount() == 0) {
                    return ResponseHttp::status400('Productos No encontrada');
                } else {

                    $dat = $query->fetchAll(\PDO::FETCH_ASSOC);
                    $data = [];
                    foreach ($dat as $res) {

                        array_push($data, [
                            'id'  => $res['producto_id'],
                            'codigo'  => $res['producto_codigo'],
                            'nombre'  => $res['producto_nombre'],
                            'precio'  => number_format(  $res['producto_precio'],2),
                            'stock'  => $res['producto_stock'],
                            'foto'  => Security::getUrlBase() ."/img/".$res['producto_foto'],
                            'subcategoria_id'  => $res['sub_categoria_id'],
                            'subcategoria_nombre'  => $res['sub_categoria_nombre'],
                            'usuario_id'  => $res['usuario_id'],
                            'usuario_nombre'  => $res['usuario_nombre'],
                        ]);
                    }
                    return ResponseHttp::status200('completado', $data);
                }
            }
        } catch (\PDOException $e) {
            error_log("SubCategoryModel::getCategorySearch -> " . $e);
            die(json_encode(ResponseHttp::status500('No se pueden obtener los datos de la sub_categoria')));
        }
    }

    /************************** Eliminar**************************/
    final public static function deleteCategory()
    {
        try {
            $con   = self::getConnection();
            $query = $con->prepare("DELETE FROM sub_categoria WHERE sub_categoria_id = :id");
            $query->execute([
                ':id' => self::getId()
            ]);

            if ($query->rowCount() > 0) {
                return ResponseHttp::status200('Subcategoría eliminada exitosamente');
            } else {
                return ResponseHttp::status500('Subcategoría no encontrada');
            }
        } catch (\PDOException $e) {
            error_log("SubCategoryModel::deleteCategory -> " . $e);
            die(json_encode(ResponseHttp::status500('No se puede eliminar la Subcategoría')));
        }
    }
}
