<?php

use App\Config\ResponseHttp;
use App\Controllers\ProductController;

/*************Parametros enviados por la URL*******************/
$params  = explode('/' ,$_GET['route']);

/*************Instancia del controlador**************/
$app = new ProductController();

/*************Rutas***************/
$app->getAll('product/');
$app->postSave('product/');
$app->getProduct("product/{$params[1]}");
$app->patchUpdate('product/update/');
$app->getProductSearch('product/search/');
$app->deleteProduct('product/');


/****************Error 404*****************/
echo json_encode(ResponseHttp::status404());