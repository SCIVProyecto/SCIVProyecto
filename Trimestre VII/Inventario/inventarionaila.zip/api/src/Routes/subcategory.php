<?php

use App\Config\ResponseHttp;
use App\Controllers\SubCategoryController;

/*************Parametros enviados por la URL*******************/
$params  = explode('/' ,$_GET['route']);

/*************Instancia del controlador**************/
$app = new SubCategoryController();

/*************Rutas***************/
$app->getAll('subcategory/');
$app->postSave('subcategory/');
$app->getCategory("subcategory/{$params[1]}");
$app->patchUpdate('subcategory/update/');
$app->getCategorySearch('subcategory/search/');
$app->getProducts('subcategory/products/');
$app->deleteCategory('subcategory/');


/****************Error 404*****************/
echo json_encode(ResponseHttp::status404());